package org.poo.playingcards;

import java.util.ArrayList;

public final class Disciple extends Cards {
    public Disciple() {
        super();
    }

    public Disciple(final int mana, final int health, final int attackDamage,
                    final String description, final ArrayList<String> colors,
                    final String name) {
        super(mana, health, attackDamage, description, colors, name);
    }

    @Override
    public void useAbility(final Cards card) {
        System.out.println("Disciple use ability");
        card.setHealth(card.getHealth() + 2);
        setUsed(true);
    }
}
